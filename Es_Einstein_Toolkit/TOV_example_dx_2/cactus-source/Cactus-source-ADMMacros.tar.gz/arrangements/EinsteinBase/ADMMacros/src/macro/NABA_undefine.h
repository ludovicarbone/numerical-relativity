/*@@
  @header   NABA_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef NABA_GUTS

#include "UPPERMET_undefine.h"
#include "CDCDA_undefine.h"


