/*@@
  @header   CDK_undefine.h
  @date     Aug 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef CDK_GUTS

#include "CDXCDK_undefine.h"
#include "CDYCDK_undefine.h"
#include "CDZCDK_undefine.h"

