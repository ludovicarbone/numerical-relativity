/*@@
  @header   DZZDG_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DZZDG_GUTS

#include "DZDG_undefine.h"

