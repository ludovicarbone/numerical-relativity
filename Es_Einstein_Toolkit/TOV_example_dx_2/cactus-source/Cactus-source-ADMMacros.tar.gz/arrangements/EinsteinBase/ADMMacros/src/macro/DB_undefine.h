/*@@
  @header   DB_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DB_GUTS

#include "DXDB_undefine.h"
#include "DYDB_undefine.h"
#include "DZDB_undefine.h"

