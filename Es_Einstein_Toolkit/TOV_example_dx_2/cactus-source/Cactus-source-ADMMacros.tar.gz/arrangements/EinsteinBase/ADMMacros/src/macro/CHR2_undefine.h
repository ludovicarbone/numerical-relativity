/*@@
  @header   CHR2_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef CHR2_GUTS

#include "CHR1_undefine.h"
#include "UPPERMET_undefine.h"

