/*@@
  @header   TRRICCI_undefine.h
  @date     August 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef TRRICCI_GUTS

#include "UPPERMET_undefine.h"
#include "RICCI_undefine.h"


  
