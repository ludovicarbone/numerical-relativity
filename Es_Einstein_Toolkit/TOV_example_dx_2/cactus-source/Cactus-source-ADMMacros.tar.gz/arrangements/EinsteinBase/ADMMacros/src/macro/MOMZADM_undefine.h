/*@@
  @header   MOMZADM_undefine.h
  @date     Aug 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef MOMZADM_GUTS

#include "UPPERMET_undefine.h"
#include "CDK_undefine.h"





