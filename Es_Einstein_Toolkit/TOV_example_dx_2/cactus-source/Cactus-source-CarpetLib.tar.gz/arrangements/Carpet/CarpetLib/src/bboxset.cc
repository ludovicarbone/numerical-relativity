#include "bboxset.hh"

#ifdef CARPET_WARN_DISABLE_BBOXSET2
#warning                                                                       \
    "Disabling Carpet's new bboxset class, since the C++ compiler does not support C++11. This leads to reduced performance on large core counts."
#endif
